<?php
$title = 'MULTI MATTE - Films &amp; Recordings';



$output = tampletLoader('../templates/user/submit_r.php',['light'=>$_GET['light'],'grip'=>$_GET['grip'],'camera'=>$_GET['camera'],'screen'=>$_GET['screen'],'lens'=>$_GET['lens']]);

?>
