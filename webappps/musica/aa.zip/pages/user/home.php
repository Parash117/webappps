<?php
  var_dump($_SESSION);
$title = 'MULTI MATTE - Films &amp; Recordings';
$output = tampletLoader('../templates/user/homepage.html.php',[]);
 ?>
