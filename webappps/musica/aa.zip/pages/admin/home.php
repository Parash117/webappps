<?php
$title="Admin Home";
$output=tampletLoader('../templates/admin/home_template.php',[]);
 ?>
