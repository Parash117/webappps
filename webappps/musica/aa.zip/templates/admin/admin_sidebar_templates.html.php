<section class="left">
  <ul id="functions">
    <li><a href="product">Products</a></li>
    <li><a href="cover">Cover</a></li>
    <li><a href="work">Our Work</a></li>
  </ul>
</section>
