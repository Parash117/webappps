<div class="breadcumb-area bg-img bg-overlay2" style="background-image: url(../img/bg-img/all_logo.jpg);">
<div class="bradcumbContent">
        <h2>Services</h2>
    </div>
</div>
 <div class="bg-gradients"></div>


<div class="col-12" style="margin-top: 150px; margin-left: 25%;">
                <!-- Loaders Area Start -->
                <div class="our-skills-area">
                    <div class="row">

                        <!-- Single Skills Area -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-skils-area mb-100">
                                <div id="circle" class="circle" data-value="0.90">
                                    <div class="skills-text">
                                        <span>90%</span>
                                    </div>
                                </div>
                                <h5>Our Skill Rating</h5>
                                <p></p>
                            </div>
                        </div>

                        <!-- Single Skills Area -->
                        <div class="col-12 col-sm-6 col-lg-3">
                            <div class="single-skils-area mb-100">
                                <div id="circle2" class="circle" data-value="0.80">
                                    <div class="skills-text">
                                        <span>80%</span>
                                    </div>
                                </div>
                                <h5>Our Equipments</h5>
                                <p></p>
                            </div>
                        </div>



                    </div>
                </div>
            </div>




<!-- ##### Upcoming Shows Area Start ##### -->
<div class="upcoming-shows-area section-padding-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading">
                    <h2></h2>
                    <h6></h6>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <!-- Upcoming Shows Content -->
                <div class="upcoming-shows-content">

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>1 <span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/red_cam.png" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Canera Rental</h6>
                                <p>RED EPIC DRAGON, RED EPIC-X Cameras</p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="productlist?cpid=3" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>2<span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/lens.png" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Lens Rental</h6>
                                <p>Ultra Primes, T 1.9* - 2 sets (16, 24, 32, 50, 85)
Zeiss CP2 High Speed Multiple sets (15,18,21, 25, 35, 50, 85,135)
Multiple sets Wide angle 11-16mm Lens</p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="productlist?cpid=5" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>3<span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/light.jpg" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Lights &amp; Equipments</h6>
                                <p>Arri Sun 25/40, Par 1.8, Mf 2000, Panel, C-stand, 3 Riser stand, Scremer and all the latest equipments and lights. </p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="productlist?cpid=1" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>4 <span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/bg-img/s4.jpg" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Dubbing</h6>
                                <p>5.1 Dolby Digital
Music (Scoring, Sound Effects, Sound Effects Design/Production) </p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="#" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>5<span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/color-icon.jpg" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Color Correction</h6>
                                <p>SCRATCH, DaVinci Resolve with TANGENT WAVE Panel</p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="#" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>6<span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/edit.png" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Multi Editing Suits</h6>
                                <p>Mac and PC Based
Adobe Premier Pro, Final Cut Pro X
3D Editing
</p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="#" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                    <!-- Single Upcoming Shows -->
                    <div class="single-upcoming-shows d-flex align-items-center flex-wrap">
                        <div class="shows-date">
                            <h2>7<span></span></h2>
                        </div>
                        <div class="shows-desc d-flex align-items-center">
                            <div class="shows-img">
                                <img src="../img/services-pic/Gimbal.png" alt="">
                            </div>
                            <div class="shows-name">
                                <h6>Steadicam Pro-Line or Ronin</h6>
                                <p>40" Jony Jib with Remote Head, View Factor remote on/off
Dji Ronin
</p>
                            </div>
                        </div>
                        <div class="shows-location">
                            <p></p>
                        </div>
                        <div class="shows-time">
                            <p></p>
                        </div>
                        <div class="buy-tickets">
                            <a href="#" class="btn musica-btn">View Details</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- ##### Upcoming Shows Area End ##### -->
