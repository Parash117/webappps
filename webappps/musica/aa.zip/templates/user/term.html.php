
    <div class="breadcumb-area bg-img bg-overlay2" style="background-image: url(); height: 50px;">
    <div class="bradcumbContent">
            <h2>Terms &amp; Policy</h2>
        </div>
    </div>
     <div class="bg-gradients"></div>



<div class="container" style="width: 80%; margin-top: 50px;">
    <div class="row">
        <div class="col-12">

<div class="single-blog-post mb-100 wow fadeInUp" data-wow-delay="300ms">

                            <a href="#" class="post-title">MULTI MATTE - Films &amp; Recording</a>
                            <!-- Post Meta -->
                            <div class="post-meta d-flex justify-content-between">
                                <div class="post-date">
                                    <p></p>
                                </div>
                            </div>
                            <!-- bg gradients -->
                            <div class="bg-gradients mb-30 w-50"></div>
                            <!-- Post Excerpt -->
                            <p>This privacy policy has been compiled to better serve those who are concerned with how their ‘Personally identifiable information’ (PII) is being used online. PII, as used in US privacy law and information security, is information that can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context. Please read our privacy policy carefully to get a clear understanding of how we collect, use, protect or otherwise handle your Personally Identifiable Information in accordance with our website.

What personal information do we collect from the people that visit our blog, website or app?

When ordering or registering on our site, as appropriate, you may be asked to enter your name, email address or other details to help you with your experience.
<br>
<h5>When do we collect information??</h5>

We collect information from you when you respond to a survey or enter information on our site.
<br><br>
<h5>How do we use your information?</h5>

We may use the information we collect from you when you register, make a purchase, sign up for our newsletter, respond to a survey or marketing communication, surf the website, or use certain other site features in the following ways:
<br><br>
• To allow us to better service you in responding to your customer service requests.
<br>
• To send periodic emails regarding your order or other products and services.
<br><br>
<h5>How do we protect visitor information?</h5>
<br>

We use third parties to collect personal information that is fully compliant with safe data collection practices.
<br><br>
<h5>Do we use ‘cookies’?
</h5>
We do not use cookies for tracking purposes
<br>
You can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies. You do this through your browser (like Internet Explorer) settings. Each browser is a little different, so look at your browser’s Help menu to learn the correct way to modify your cookies.
<br>
If you disable cookies off, some features will be disabled that make your site experience more efficient and some of our services will not function properly. However, you can still place orders .
<br><br>
<h5>Third Party Disclosure?
</h5>
We do not sell, trade, or otherwise transfer to outside parties your personally identifiable information.
<br><br>
<h5>Third party links
</h5>
We do not include or offer third party products or services on our website.
<br><br>
<h5>Google
</h5>
Google’s advertising requirements can be summed up by Google’s Advertising Principles. They are put in place to provide a positive experience for users. https://support.google.com/adwordspolicy/answer/1316548?hl=en
<br>
We have not enabled Google AdSense on our site but we may do so in the future.
<br><br>
<h5>
COPPA (Children Online Privacy Protection Act)
</h5>
When it comes to the collection of personal information from children under 13, the Children’s Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, the nation’s consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect children’s privacy and safety online.
<br>
We do not specifically market to children under 13.
<br><br>
<h5>
Fair Information Practices
</h5>
The Fair Information Practices Principles form the backbone of privacy law in the United States and the concepts they include have played a significant role in the development of data protection laws around the globe. Understanding the Fair Information Practice Principles and how they should be implemented is critical to comply with the various privacy laws that protect personal information.
<br>
In order to be in line with Fair Information Practices we will take the following responsive action, should a data breach occur: • Within 7 business days
<br>
We will notify the users via in site notification • Within 7 business days
<br>
We also agree to the individual redress principle, which requires that individuals have a right to pursue legally enforceable rights against data collectors and processors who fail to adhere to the law. This principle requires not only that individuals have enforceable rights against data users, but also that individuals have recourse to courts or a government agency to investigate and/or prosecute non-compliance by data processors.
<br><br>
<h5>
CAN SPAM Act
</h5>
The CAN-SPAM Act is a law that sets the rules for commercial email, establishes requirements for commercial messages, gives recipients the right to have emails stopped from being sent to them, and spells out tough penalties for violations.
<br>
We collect your email address in order to:?• Send information, respond to inquiries, and/or other requests or questions.?• Process orders and to send information and updates pertaining to orders?• We may also send you additional information related to your product and/or service.?• Market to our mailing list or continue to send emails to our clients after the original transaction has occurred
<br>
To be accordance with CANSPAM we agree to the following:?• NOT use false, or misleading subjects or email addresses?• Identify the message as an advertisement in some reasonable way?• Include the physical address of our business or site headquarters?• Monitor third party email marketing services for compliance, if one is used. • Honor opt-out/unsubscribe requests quickly?• Allow users to unsubscribe by using the link at the bottom of each email
<br>
If at any time you would like to unsubscribe from receiving future emails, you can • Follow the instructions at the bottom of each email.
<br><br>
<h5>Contacting Us:</h5>

To contact us, please use the contact form provided at the bottom of the home page at www.multimatte.tk or at our mailing address.</p>
                        </div>
</div>
</div>
</div>
